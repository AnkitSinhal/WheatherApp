package com.test.weatherapp.ui.activities

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import com.test.weatherapp.R
import com.test.weatherapp.data.local.WeatherDatabase
import com.test.weatherapp.data.network.ApiInterface
import com.test.weatherapp.data.network.NetworkConnectionInterceptor
import com.test.weatherapp.data.repositories.WeatherRepository
import com.test.weatherapp.databinding.ActivityWeatherBinding
import com.test.weatherapp.ui.adapters.BookmarkCityAdapter
import com.test.weatherapp.ui.viewmodel.WeatherViewModel
import com.test.weatherapp.ui.viewmodelfactory.WeatherViewModelFactory
import com.test.weatherapp.util.*

class WeatherActivity : AppCompatActivity() {

    private lateinit var dataBind: ActivityWeatherBinding
    private lateinit var viewModel: WeatherViewModel
    private lateinit var bookmarkCityAdapter: BookmarkCityAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dataBind = DataBindingUtil.setContentView(this, R.layout.activity_weather)
        viewModel = ViewModelProviders.of(
            this, WeatherViewModelFactory(
                WeatherRepository(
                    ApiInterface.invoke(NetworkConnectionInterceptor(this)),
                    WeatherDatabase.invoke(this)
                )
            )
        ).get(WeatherViewModel::class.java)

        setupUI()
        observeAPICall()
    }

    private fun setupUI() {
        initializeRecyclerView()
        // Fetch Bookmark Cities
        viewModel.fetchBookmarkCityFromDb()

        dataBind.inputFindCityWeather.setOnEditorActionListener { view, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                viewModel.fetchWeatherDetailFromDb((view as EditText).text.toString())
            }
            false
        }
        dataBind.imageBookmark.setOnClickListener { event ->
            viewModel.addBookmarkCityIntoDb(dataBind.textCityName.text.toString())
        }

        dataBind.textHelp.setOnClickListener { event ->
            startActivity(Intent(this, HelpActivity::class.java))
        }
    }

    private fun initializeRecyclerView() {
        bookmarkCityAdapter = BookmarkCityAdapter()
        val mLayoutManager = LinearLayoutManager(
            this,
            LinearLayoutManager.HORIZONTAL,
            false
        )
        dataBind.recyclerViewSearchedCityTemperature.apply {
            layoutManager = mLayoutManager
            itemAnimator = DefaultItemAnimator()
            adapter = bookmarkCityAdapter
        }
    }

    @SuppressLint("SetTextI18n")
    private fun observeAPICall() {
        viewModel.weatherLiveData.observe(this, EventObserver { state ->
            when (state) {
                is State.Loading -> {
                }
                is State.Success -> {
                    dataBind.textLabelSearchForCity.hide()
                    dataBind.imageCity.hide()
                    dataBind.constraintLayoutShowingTemp.show()
                    dataBind.inputFindCityWeather.text?.clear()
                    state.data.let { weatherDetail ->
                        val iconCode = weatherDetail.icon?.replace("n", "d")
                        AppUtils.setGlideImage(
                            dataBind.imageWeatherSymbol,
                            AppConstants.WEATHER_API_IMAGE_ENDPOINT + "${iconCode}@4x.png"
                        )
                        changeBgAccToTemp(iconCode)
                        dataBind.textTodaysDate.text =
                            AppUtils.getCurrentDateTime(AppConstants.DATE_FORMAT)
                        dataBind.textTemperature.text = weatherDetail.temp.toString()
                        dataBind.textCityName.text =
                            "${weatherDetail.cityName?.capitalize()}, ${weatherDetail.countryName}"
                        dataBind.textWind.text = "Wind Speed : ${weatherDetail.wind.toString()}"
                        dataBind.textHumidity.text =
                            "Humidity : ${weatherDetail.humidity.toString()}"
                    }

                }
                is State.Error -> {
                    showToast(state.message)
                }
            }
        })

        viewModel.weatherDetailListLiveData.observe(this, EventObserver { state ->
            when (state) {
                is State.Loading -> {
                }
                is State.Success -> {
                    if (state.data.isEmpty()) {
                        dataBind.recyclerViewSearchedCityTemperature.hide()
                    } else {
                        dataBind.recyclerViewSearchedCityTemperature.show()
                        bookmarkCityAdapter.setData(state.data)
                        bookmarkCityAdapter.notifyDataSetChanged()
                    }
                }
                is State.Error -> {
                    showToast(state.message)
                }
            }
        })
    }

    private fun changeBgAccToTemp(iconCode: String?) {
        when (iconCode) {
            "01d", "02d", "03d" -> dataBind.imageWeatherHumanReaction.setImageResource(R.drawable.sunny_day)
            "04d", "09d", "10d", "11d" -> dataBind.imageWeatherHumanReaction.setImageResource(R.drawable.rain_day)
            "13d", "50d" -> dataBind.imageWeatherHumanReaction.setImageResource(R.drawable.cloudy_day)
        }
    }


}
