package com.test.weatherapp.data.repositories

import com.test.weatherapp.data.local.WeatherDatabase
import com.test.weatherapp.data.model.WeatherDataResponse
import com.test.weatherapp.data.model.WeatherDetail
import com.test.weatherapp.data.network.ApiInterface
import com.test.weatherapp.data.network.SafeApiRequest

class WeatherRepository(
    private val api: ApiInterface,
    private val db: WeatherDatabase
) : SafeApiRequest() {

    suspend fun findCityWeather(cityName: String): WeatherDataResponse = apiRequest {
        api.findCityWeatherData(cityName)
    }

    suspend fun addCity(weatherDetail: WeatherDetail) {
        db.getWeatherDao().insertCity(weatherDetail)
    }

    suspend fun fetchWeatherDetail(cityName: String): WeatherDetail? =
        db.getWeatherDao().fetchWeatherByCity(cityName)

    suspend fun fetchAllBookMarkCity(): List<String> =
        db.getWeatherDao().fetchAllBookMarkCity()
}

