package com.test.weatherapp.ui.adapters

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.test.weatherapp.R
import com.test.weatherapp.databinding.ListItemBookmarkCityBindingImpl

class BookmarkCityAdapter :
    RecyclerView.Adapter<BookmarkCityAdapter.ViewHolder>() {

    private val weatherDetailList = ArrayList<String>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding: ListItemBookmarkCityBindingImpl = DataBindingUtil.inflate(
            LayoutInflater.from(parent.context),
            R.layout.list_item_bookmark_city,
            parent,
            false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindItems(weatherDetailList[position])
    }

    override fun getItemCount(): Int = weatherDetailList.size

    fun setData(
        newWeatherDetail: List<String>
    ) {
        weatherDetailList.clear()
        weatherDetailList.addAll(newWeatherDetail)
        notifyDataSetChanged()
    }

    inner class ViewHolder(private val binding: ListItemBookmarkCityBindingImpl) :
        RecyclerView.ViewHolder(binding.root) {

        @SuppressLint("SetTextI18n")
        fun bindItems(weatherDetail: String) {
            binding.apply {
                textCityName.text = "${weatherDetail.capitalize()}"
            }
        }
    }
}