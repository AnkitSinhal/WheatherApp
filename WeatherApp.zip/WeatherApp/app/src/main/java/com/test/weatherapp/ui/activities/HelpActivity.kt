package com.test.weatherapp.ui.activities

import android.os.Bundle
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import com.test.weatherapp.R

class HelpActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_help)

        findViewById<WebView>(R.id.web_view).loadUrl("https://openweathermap.org/faq")
    }
}
